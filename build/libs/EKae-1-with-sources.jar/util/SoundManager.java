package util;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * SoundManager.java
 * จัดการเสียงทั้งหมดในเกม ใช้ Singleton pattern
 * AudioClip สำหรับ sfx สั้น และ MediaPlayer สำหรับ bgm
 */
public class SoundManager {

    private static SoundManager instance;

    private final Map<String, AudioClip> clips = new HashMap<>();
    private final Map<String, MediaPlayer> tracks = new HashMap<>();
    private boolean muted = false;

    private SoundManager() {
        loadClip("ArrowTower", "/sounds/tower/ArrowTower.mp3");
        loadClip("CannonTower", "/sounds/tower/CannonTower.mp3");
        loadClip("IceTower", "/sounds/tower/IceTower.mp3");

        loadClip("game_over", "/sounds/game_over.mp3");

        loadTrack("bgm", "/sounds/bgm.mp3");
    }

    public static SoundManager getInstance() {
        if (instance == null) instance = new SoundManager();
        return instance;
    }

    private void loadClip(String key, String path) {
        try {
            var url = getClass().getResource(path);
            if (url != null) clips.put(key, new AudioClip(url.toString()));
            else System.out.println("Clip not found: " + path);
        } catch (Exception e) {
            System.out.println("Failed to load clip: " + path);
        }
    }

    private void loadTrack(String key, String path) {
        try {
            var url = getClass().getResource(path);
            if (url != null) {
                Media media = new Media(url.toString());
                MediaPlayer player = new MediaPlayer(media);
                player.setCycleCount(MediaPlayer.INDEFINITE);  // loop
                tracks.put(key, player);
            } else {
                System.out.println("Track not found: " + path);
            }
        } catch (Exception e) {
            System.out.println("Failed to load track: " + path);
        }
    }

    // play sound effect
    public void play(Object obj) {
        if (obj == null) return;

        String key;
        if (obj instanceof String) {
            key = (String) obj;
        } else {
            key = obj.getClass().getSimpleName();
        }

        if (clips.containsKey(key)) {
            clips.get(key).play();
        } else if (tracks.containsKey(key)) {
            tracks.get(key).seek(tracks.get(key).getStartTime());
            tracks.get(key).play();
        }
    }

    // play background sound, loop
    public void playBgm() {
        if (!tracks.containsKey("bgm")) return;
        tracks.get("bgm").play();
    }

    public void stopBgm() {
        if (tracks.containsKey("bgm")) tracks.get("bgm").stop();
    }

    public void pauseBgm() {
        if (tracks.containsKey("bgm")) tracks.get("bgm").pause();
    }

    public boolean isMuted() {
        return muted;
    }

    public void setMuted(boolean muted) {
        this.muted = muted;

        double volume = muted ? 0.0 : 1.0;

        for (MediaPlayer player : tracks.values()) {
            player.setVolume(volume);
        }

        for (AudioClip clip : clips.values()) {
            clip.setVolume(volume);
        }

    }
}